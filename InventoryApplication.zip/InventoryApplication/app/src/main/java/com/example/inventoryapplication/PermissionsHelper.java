package com.example.inventoryapplication;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.telephony.TelephonyManager;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class PermissionsHelper {

    private static final int PHONE_PERMISSION_CODE = 1001;
    private Context context;


    public PermissionsHelper(Context context) {
        this.context = context;
    }

    public boolean hasPhonePermission() {
        return ContextCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE)
                == PackageManager.PERMISSION_GRANTED;
    }

    public void requestPhonePermission(Activity activity) {
        ActivityCompat.requestPermissions(activity, new String[]{Manifest.permission.READ_PHONE_STATE}, PHONE_PERMISSION_CODE);
    }

    @SuppressLint("MissingPermission")
    public String retrievePhoneNumber() {
        if (!hasPhonePermission()) {
            return null;
        }

        try {
            TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
            if (telephonyManager != null) {
                String phoneNumber = telephonyManager.getLine1Number();
                return (phoneNumber != null && !phoneNumber.isEmpty()) ? phoneNumber : null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

}
