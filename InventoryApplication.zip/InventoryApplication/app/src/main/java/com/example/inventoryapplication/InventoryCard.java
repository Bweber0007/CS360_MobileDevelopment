package com.example.inventoryapplication;

public class InventoryCard {
    private String itemName;
    private String count;

    public InventoryCard(String itemName, String count) {
        this.itemName = itemName;
        this.count = count;
    }

    public String getItemName() {
        return itemName;
    }

    public String getCount() {
        return count;
    }

    public String increaseCount(){
        int num = Integer.parseInt(count);
        num++;
        count = Integer.toString(num);
        return count;
    }

    public String decreaseCount(){
        int num = Integer.parseInt(count);
        num--;
        count = Integer.toString(num);
        return count;
    }

    public void setCount(String count){
        this.count = count;
    }
}