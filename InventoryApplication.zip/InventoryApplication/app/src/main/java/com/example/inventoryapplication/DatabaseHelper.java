package com.example.inventoryapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "inventoryDB";
    private static final int DATABASE_VERSION = 1;

    // Users table
    private static final String TABLE_USERS = "users_table";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASSWORD = "password";

    // Inventory table
    private static final String TABLE_INVENTORY = "inventory_table";
    private static final String COLUMN_NAME = "name";
    private static final String COLUMN_COUNT = "count";


    // Constructor
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create users table
        String createUsersTableQuery = "CREATE TABLE " + TABLE_USERS + " (" +
                COLUMN_USERNAME + " TEXT PRIMARY KEY, " +
                COLUMN_PASSWORD + " TEXT)";
        db.execSQL(createUsersTableQuery);

        // Create inventory table
        String createInventoryTableQuery = "CREATE TABLE " + TABLE_INVENTORY + " (" +
                COLUMN_NAME + " TEXT PRIMARY KEY, " +
                COLUMN_COUNT + " TEXT)";
        db.execSQL(createInventoryTableQuery);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INVENTORY);
        onCreate(db);
    }

    // Add a new user
    public boolean addUser(String username, String password) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password);

        long result = db.insert(TABLE_USERS, null, values);
        return result != -1; // Return true if user added successfully
    }

    // Validate user login
    public boolean validateUser(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS, null,
                COLUMN_USERNAME + "=? AND " + COLUMN_PASSWORD + "=?",
                new String[]{username, password}, null, null, null);

        boolean isValid = cursor.moveToFirst();
        cursor.close();
        return isValid;
    }

    // Add an inventory item
    public boolean addInventoryItem(String name, String count) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, name);
        values.put(COLUMN_COUNT, count);

        return db.insert(TABLE_INVENTORY, null, values) != -1;
    }

    // Delete an inventory item
    public void deleteInventoryItem(String name) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(TABLE_INVENTORY, COLUMN_NAME + " = ?", new String[]{name});
    }

    // Update an inventory item
    public void updateInventoryItem(String oldName, String newName, String newCount) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, newName);
        values.put(COLUMN_COUNT, newCount);

        db.update(TABLE_INVENTORY, values, COLUMN_NAME + " = ?", new String[]{oldName});
    }

    // Retrieve all inventory items
    public ArrayList<InventoryCard> getAllInventoryItems() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(TABLE_INVENTORY, null, null, null, null, null, null);

        ArrayList<InventoryCard> inventoryList = new ArrayList<>();
        if (cursor != null && cursor.moveToFirst()) {
            do {
                String name = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NAME));
                String count = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_COUNT));

                InventoryCard item = new InventoryCard(name, count);
                inventoryList.add(item);
            } while (cursor.moveToNext());
            cursor.close();
        }

        return inventoryList;
    }

    // Close the database (optional)
    public void closeDatabase() {
        SQLiteDatabase db = getReadableDatabase();
        if (db != null && db.isOpen()) {
            db.close();
        }
    }
}

