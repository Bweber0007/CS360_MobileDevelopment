package com.example.inventoryapplication;

import android.annotation.SuppressLint;
import android.content.Context;
import android.telephony.SmsManager;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import android.widget.Toast;

import java.util.List;

public class smsHelper {

    private Context context;

    public smsHelper(Context context) {
        this.context = context;
    }

    public void sendSmsNotification(String phoneNumber, String message) {
        if (isSmsPermissionDenied()) {
            Toast.makeText(context, "SMS permission denied. Cannot send notifications.", Toast.LENGTH_SHORT).show();
            return;
        }

        SmsManager smsManager = context.getSystemService(SmsManager.class);
        if (smsManager != null) {
            try {
                smsManager.sendTextMessage(phoneNumber, null, message, null, null);
                Toast.makeText(context, "SMS sent successfully!", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(context, "Failed to send SMS: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(context, "No active subscription available to send SMS.", Toast.LENGTH_SHORT).show();
        }
    }

    // Helper to check if SMS permission was explicitly denied
    private boolean isSmsPermissionDenied() {
        return context.getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
                .getBoolean("sms_permission_denied", false);
    }

    public String getSavedPhoneNumber() {
        return context.getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
                .getString("user_phone_number", null);
    }

    public void savePhoneNumber(String phoneNumber) {
        context.getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
                .edit()
                .putString("user_phone_number", phoneNumber)
                .apply();
    }
}
