package com.example.inventoryapplication;

import android.app.Dialog;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;


public class InventoryActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private CardAdapter adapter;
    private DatabaseHelper dbHelper;
    private ArrayList<InventoryCard> cardDataList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.inventory_screen);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));

        dbHelper = new DatabaseHelper(this);

        loadInventoryData();

        // Set up the FloatingActionButton
        findViewById(R.id.addButton).setOnClickListener(view -> showAddItemDialog());
    }

    private void loadInventoryData() {
        // Fetch inventory data from the database
        cardDataList = dbHelper.getAllInventoryItems();
        adapter = new CardAdapter(cardDataList, this);
        recyclerView.setAdapter(adapter);
    }

    private void showAddItemDialog() {
        // Create a dialog
        Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.add_item);
        dialog.setTitle("Add New Item");

        EditText itemNameInput = dialog.findViewById(R.id.itemNameInput);
        EditText itemCountInput = dialog.findViewById(R.id.itemCountInput);
        Button addItemButton = dialog.findViewById(R.id.addItemButton);

        // Handle the Add Item button click
        addItemButton.setOnClickListener(view -> {
            String itemName = itemNameInput.getText().toString().trim();
            String itemCount = itemCountInput.getText().toString().trim();

            if (itemName.isEmpty() || itemCount.isEmpty()) {
                Toast.makeText(InventoryActivity.this, "Please fill out all fields", Toast.LENGTH_SHORT).show();
            } else {


                // Add the new item to the database
                if (dbHelper.addInventoryItem(itemName, itemCount)) {
                    Toast.makeText(InventoryActivity.this, "Item added successfully", Toast.LENGTH_SHORT).show();
                    dialog.dismiss();
                    loadInventoryData(); // Refresh the RecyclerView
                } else {
                    Toast.makeText(InventoryActivity.this, "Failed to add item", Toast.LENGTH_SHORT).show();
                }
            }
        });

        dialog.show();
    }



}

