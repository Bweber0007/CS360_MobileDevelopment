package com.example.inventoryapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class PermissionsActivity extends AppCompatActivity {

    private PermissionsHelper permissionsHelper;
    private smsHelper smsHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sms_notification_screen);

        Button grantPermissionButton = findViewById(R.id.grantPermissionButton);
        Button denyPermissionButton = findViewById(R.id.denyPermissionButton);

        permissionsHelper = new PermissionsHelper(this);
        smsHelper = new smsHelper(this);

        grantPermissionButton.setOnClickListener(view -> {
            if (!permissionsHelper.hasPhonePermission()) {
                permissionsHelper.requestPhonePermission(this);
            } else {
                // Reset the denial flag since permission was granted
                getSharedPreferences("app_prefs", MODE_PRIVATE)
                        .edit()
                        .putBoolean("sms_permission_denied", false)
                        .apply();
                handlePhoneNumber();
            }
        });

        denyPermissionButton.setOnClickListener(view -> {
            // Mark permission as denied
            getSharedPreferences("app_prefs", MODE_PRIVATE)
                    .edit()
                    .putBoolean("sms_permission_denied", true)
                    .apply();

            // Proceed to InventoryActivity without enabling SMS
            Toast.makeText(this, "Permission denied. SMS notifications disabled.", Toast.LENGTH_SHORT).show();
            proceedToInventory(null);
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (permissionsHelper.hasPhonePermission()) {
            handlePhoneNumber();
        } else {
            Toast.makeText(this, "Permission denied. SMS notifications disabled.", Toast.LENGTH_SHORT).show();
            proceedToInventory(null);
        }
    }

    private void handlePhoneNumber() {
        String phoneNumber = permissionsHelper.retrievePhoneNumber();
        if (phoneNumber == null || phoneNumber.isEmpty()) {
            // Fallback to a default number or ask user for input
            phoneNumber = "5551234567"; // Example fallback
            //Toast.makeText(this, "Default phone number used: " + phoneNumber, Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Phone Number Retrieved: " + phoneNumber, Toast.LENGTH_SHORT).show();
        }
        smsHelper.savePhoneNumber(phoneNumber);
        proceedToInventory(phoneNumber);
    }

    private void proceedToInventory(String phoneNumber) {
        Intent intent = new Intent(this, InventoryActivity.class);
        if (phoneNumber != null) {
            intent.putExtra("phone_number", phoneNumber);
        }
        startActivity(intent);
        finish();
    }
}

