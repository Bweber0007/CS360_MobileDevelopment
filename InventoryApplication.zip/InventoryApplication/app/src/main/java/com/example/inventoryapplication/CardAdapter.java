package com.example.inventoryapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;


public class CardAdapter extends RecyclerView.Adapter<CardAdapter.InventoryViewHolder> {

    private ArrayList<InventoryCard> inventoryList;
    private DatabaseHelper dbHelper;
    private smsHelper sms;
    private PermissionsHelper permissionsHelper;

    public CardAdapter(ArrayList<InventoryCard> inventoryList, Context context) {
        this.inventoryList = inventoryList;
        this.dbHelper = new DatabaseHelper(context); // Access the database to update values
        this.sms = new smsHelper(context);
        this.permissionsHelper = new PermissionsHelper(context);
    }

    @NonNull
    @Override
    public InventoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.inventory_item_card, parent, false);
        return new InventoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull InventoryViewHolder holder, int position) {
        InventoryCard card = inventoryList.get(position);

        // Set item details
        holder.itemName.setText(card.getItemName());
        holder.itemCount.setText(card.getCount());

        // Increase count button
        holder.increaseButton.setOnClickListener(v -> {
            String newCount = card.increaseCount();
            card.setCount(newCount); // Update the object
            dbHelper.updateInventoryItem(card.getItemName(), card.getItemName(), newCount); // Update the database
            notifyItemChanged(position); // Notify the RecyclerView to refresh this item
        });

        // Decrease count button
        holder.decreaseButton.setOnClickListener(v -> {
            if (Integer.parseInt(card.getCount()) > 0) { // Ensure count doesn't go below zero
                String newCount = card.decreaseCount();
                card.setCount(newCount); // Update the object
                dbHelper.updateInventoryItem(card.getItemName(), card.getItemName(), newCount); // Update the database
                notifyItemChanged(position); // Notify the RecyclerView to refresh this item
            }
            if(Integer.parseInt(card.getCount())==0){
                String number = sms.getSavedPhoneNumber();
                String message = card.getItemName() + " is out of stock!";
                if(permissionsHelper.hasPhonePermission()) {
                    sms.sendSmsNotification(number, message);
                }
            }
        });

        // Delete button
        holder.deleteButton.setOnClickListener(v -> {
            // Remove the item from the database
            dbHelper.deleteInventoryItem(card.getItemName());

            // Remove the item from the list
            inventoryList.remove(position);

            // Notify the RecyclerView about the removed item
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, inventoryList.size());
        });
    }

    @Override
    public int getItemCount() {
        return inventoryList.size();
    }

    // ViewHolder class
    public static class InventoryViewHolder extends RecyclerView.ViewHolder {

        TextView itemName, itemCount;
        Button increaseButton, decreaseButton, deleteButton;

        public InventoryViewHolder(@NonNull View itemView) {
            super(itemView);
            itemName = itemView.findViewById(R.id.inventoryItem);
            itemCount = itemView.findViewById(R.id.inventoryItemCount);
            increaseButton = itemView.findViewById(R.id.increaseCount);
            decreaseButton = itemView.findViewById(R.id.decreaseCount);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }
    }
}
